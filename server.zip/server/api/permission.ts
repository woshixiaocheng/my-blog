import { Request,Response } from "express" //标注类型
let db=require('../db/api')//数据库处理封装
import commonRes from '../utils/commonRes'